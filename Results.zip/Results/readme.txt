Files heur1.json and heur2.json contain the results of computational experiments conducted with the heuristic strategies (1) and (2), respectively, as described in Sections 4 and 5 in the paper 'Exact and Heuristic Approaches for the Covering Tour Location Routing Problem', which can currently be retrieved under the following link: https://arxiv.org/abs/2411.17510v1.
File mip.json contains the results of the same experiments when solving the proposed exact model using gurobi, as described in Section 3 and 5.


High-level data is summarized into the following .csv files:
>>>1. Results from heuristics 1 and 2: files heur2_summary.csv and heur2_summary.csv:
	- column 'inst_name': name of the instance as stated in the Instance.zip file
	- column 'computations': number of heuristic runs finished prior to the time limit (120s)
	- columns starting with 'ls': information on min, max and average values for runtime and objective values of the solution obtained as a (final) results from the local search procedure
	- columns starting with 'cons': information on min, max and average values for runtime and objective values of the solutions obtained from the constructive heuristic
	- column 'cons_seed': Random seed to reproduce the constructive heuristic ouput which lead to the best solution after the local search stage


>>>2. Results from solving the MIP using gurobi: mip_summary.csv
	- column 'inst_name': name of the instance as stated in the Instance.zip file
	- column 'int_sol_found': indicates whether gurobi was able to find a feasible integer solution within the specified time limit
	- column 'gap_percent': absolute optimality gap in % (left blank if no integer solution has been found)
	- columns 'lb' and 'ub': best lower and upper bounds found, respectively ('ub' left blank if no integer solution has been found)
	- column 'runtime': total runtime until timelimit has been reached or optimality/infeasibility was proven


>>>3. Comparison of heuristic and MIP results: comparison_summary.csv
	- column 'inst_name': name of the instance as stated in the Instance.zip file
	- columns 'ub_mip', 'gap_percent_mip', 'runtime_mip': self-explanatory values from exactly solving the model as a MIP
	- column 'heur1_ls_obj_min': best integer solution found by heuristic 1 (analogous for column 'heur2_ls_obj_min')
	- column 'mip_outperforms_heur1': binary value indicating if the MIP was able to find a STRICTLY better solution as heuristic 1
	- column 'mip_outperforms_heur2': analogous





More granular solution data, including information on the optimal solution (routes, customer assignments, facility/depot selections) are included in files heur1.json (results from heuristic 1), heur2.json (results from heuristic 2) and mip.json (results from solving the proposed MIP using gurobi). In the following, their data structure is described.

>>>1. Heuristic results: heur1.json and heur2.json
	The solution file is formatted as follows:
	"sol_stats": Results, 1 dictionary per instance

	"[instance_name]":

		"stats":
			"customers": 		Number of customers in instance
			"depots": 		Number of depots in instance
			"facilities": 		Number of facilities in instance
			"computations": 	Number of heuristic runs finished prior to the time limit (120s)

		"constructive":
			"time (ns)": 		Runtime (ns) spent in constructive heuristic stage [min, max, mean, median, stdev]
			"obj": 			Objective value of constructive heuristic output [min, max, mean, median, stdev]
			"iterations": 		Number of calls to constructive heuristic until a feasible solution was found [min, max, mean, median, stdev]
			"opened_facilities": 	Number of opened facilities in the constructive heuristic output [min, max, mean, median, stdev]
			"opened_depots":	Number of opened depots in the constructive heuristic output [min, max, mean, median, stdev]
			"facil/vehicles":	Avg number of facilities per vehicle in the constructive heuristic output [min, max, mean, median, stdev]
			"seed":			Random seed to reproduce the constructive heuristic ouput which lead to the best solution after the local search stage

		"local_search":
			"obj":			Objective value of local search output [min, max, mean, median, stdev]
			"opened_facilities": 	Number of opened facilities in the local search output of the constructive heuristic [min, max, mean, median, stdev]
			"opened_depots":	Number of opened depots in the output of the constructive heuristic [min, max, mean, median, stdev]
			"time": 		Runtime (ns) spent in local search stage [min, max, mean, median, stdev]
			"measures":	
				"[operator]":	List with entries [I, II, III, IV]; I is the avg time (ns) spent in the operator, II is the avg number of times the operator was called, III is the avg number of times the operator found an improvement, IV is the avg cost reduction
			
			"sol":				Representation of the best solution found, explained in 

			"move_history": Internal format which represents incremental changes to the constructive heuristic output; roughly the format is as follows: 	["operator", objective value, list of changed routes, cost reduction, list of changed route indices]


>>>2. Gurobi model:  mip.json
	"sol_stats":

	"[instance_name]":

		"ctlrp":

			"info":
				"ObjectiveValue":		Objective value of MIP-output
				"LowerBound":			Lower bound of MIP-output
				"Time (s)":			MIP runtime (s)
				"Status Message":		Gurobi output status message
				"IterCount":			Gurobi iteration count
				"MIPGap (%)":			Gurobi MIP-Gap (in %)
				"NodeCount":			Gurobi Node Count
				"SolCount":			Gurobi Solution Count

			"obj":					Objective value of MIP-output

			"sep_info": 
				"added_path_constraints":	Number of added path constraints

				"Time (ms) to obj info": 	Each time an improved solution is found, a time stamp is created
					"time_stamp": 		"objbst": Objective value after time_stamp, "objbnd": MIP lower bound after time_stamp

				"Routine count": 		Number of times the separation procedure is called
				"Separation time (ms)": 	Total time (ms) spent in the separation procedure
				"Time to first feasible solution (ms)":		Time (ms) to first feasible MIP solution

			"total_time": 				Runtime (ns) of MIP
			"sol":					See the previous description

